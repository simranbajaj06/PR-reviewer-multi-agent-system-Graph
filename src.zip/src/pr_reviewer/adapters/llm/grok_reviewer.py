"""Concrete Reviewer adapter: builds the Groq LLM client and the
multi-agent orchestrator graph, and translates between the domain's
PullRequestEvent/Review and the graph's internal ReviewState.

If a GraphStore is supplied, relevant existing code is retrieved once
per review (not once per specialist), rendered into per-agent prompt
slices, and handed to the graph as `context` + `agent_context`.
"""
import logging
import os
from typing import Any

from dotenv import load_dotenv
from langchain_groq import ChatGroq

from src.pr_reviewer.domain.contracts import AgentType
from src.pr_reviewer.domain.interfaces import Reviewer
from src.pr_reviewer.domain.models import PullRequestEvent, Review
from src.pr_reviewer.graph.render import ROLE_PRESETS, render_context
from src.pr_reviewer.orchestrator.graph import build_graph

load_dotenv()
logger = logging.getLogger(__name__)

# Map each agent type to the render preset that gives it the graph
# facts most relevant to its concerns.
_AGENT_RENDER_PRESET: dict[AgentType, str] = {
    AgentType.SECURITY: "security",   # callees + references (what new code calls)
    AgentType.QUALITY: "contracts",   # callees + references + callers (API contract impact)
    AgentType.TESTS: "tests",         # tests + callers (test coverage gaps)
    AgentType.DOCS: "impact",         # callers + importers (who is affected)
}

# Fallback preset when graph context is empty or disabled.
_GENERAL_PRESET = "general"


class GroqReviewer(Reviewer):
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        graph_store: Any | None = None,  # GraphStore | None (avoid circular import)
    ):
        # Default: llama-3.3-70b-versatile (fast, good for structured output).
        # For deeper reasoning, openai/gpt-oss-120b is also on Groq's free tier.
        self._model_name = model or os.getenv("GROK_MODEL", "llama-3.3-70b-versatile")
        llm = ChatGroq(
            model=self._model_name,
            api_key=api_key or os.getenv("GROQ_API_KEY"),
            temperature=0,
        )
        self._graph = build_graph(llm)
        self._graph_store = graph_store

    def _build_context(self, event: PullRequestEvent, diff: str) -> tuple[str, dict[str, str]]:
        """Returns (generic_context_string, agent_context_dict).

        The generic string is used as fallback when an agent has no preset.
        The dict is keyed by AgentType.value so each specialist gets only
        the graph slices it cares about.
        """
        if self._graph_store is None:
            return "", {}

        try:
            # GraphStore.context() creates a retriever for the right repo graph
            # and returns a GraphContext dataclass.
            ctx = self._graph_store.context(event.repo_full_name, diff)
        except Exception as exc:
            logger.warning(
                "PR #%d graph context failed (%s); falling back to diff-only review",
                event.pr_number, exc,
            )
            return "", {}

        if ctx.is_empty:
            return "", {}

        # Generic fallback: every section, capped at 12 k chars.
        generic = render_context(ctx, sections=_GENERAL_PRESET, max_chars=12_000)

        # Per-agent slices: each specialist gets the subset of facts it needs.
        agent_ctx: dict[str, str] = {}
        for agent_type, preset in _AGENT_RENDER_PRESET.items():
            # Give each agent a slightly smaller budget so the total prompt
            # (diff + context + system prompt) stays inside the model's window.
            text = render_context(ctx, sections=preset, max_chars=8_000)
            if text:
                agent_ctx[agent_type.value] = text

        logger.info(
            "PR #%d context built: generic=%d chars, agents=%s",
            event.pr_number, len(generic),
            {k: f"{len(v)}ch" for k, v in agent_ctx.items()},
        )
        return generic, agent_ctx

    def review(self, event: PullRequestEvent, diff: str) -> Review:
        generic_context, agent_context = self._build_context(event, diff)

        result = self._graph.invoke({
            "pr_number": event.pr_number,
            "pr_title": event.pr_title,
            "diff": diff,
            "context": generic_context,
            "agent_context": agent_context,
            "findings": [],
            "overall_confidence": 1.0,
            "needs_human_review": False,
            "summary": "",
        })

        verdict = "hold" if result["needs_human_review"] else "comment"

        # Convert Pydantic Finding objects to plain dicts for serialization
        findings = []
        for f in result.get("findings", []):
            if hasattr(f, "model_dump"):
                findings.append(f.model_dump())
            elif hasattr(f, "dict"):
                findings.append(f.dict())
            else:
                findings.append(f)

        return Review(
            pr_number=event.pr_number,
            summary=result["summary"],
            verdict=verdict,
            findings=findings,
            overall_confidence=result.get("overall_confidence", 1.0),
            needs_human_review=result.get("needs_human_review", False),
        )
