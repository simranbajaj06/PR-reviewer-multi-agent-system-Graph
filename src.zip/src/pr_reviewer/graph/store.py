"""FalkorDB access for the app: one graph per repository.

  graph_name("owner/name") -> "owner__name"   (or GRAPH_NAME for every repo, see below)

Responsibilities
  * exists / indexed_sha   -> is there a graph, and which commit does it reflect?
  * replace(...)           -> load a freshly analysed repo and swap it in ATOMICALLY
  * context(repo, diff)    -> the reviewer's read path (Cypher via GraphContextRetriever)

Atomic swap: the new graph is built under "<name>__building" and then moved onto
"<name>" with a Redis RENAME (graphs are Redis keys). Reviews running during a
rebuild keep reading the old graph; they never see a half-built one.
"""
from __future__ import annotations

import logging
import re
from typing import Any

from src.pr_reviewer.graph.build_graph import load_graph
from src.pr_reviewer.graph.retriever import GraphContext, GraphContextRetriever

logger = logging.getLogger(__name__)

_BUILDING_SUFFIX = "__building"


class GraphStore:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        password: str | None = None,
        *,
        fixed_graph_name: str | None = None,
        db: Any = None,                     # inject a FalkorDB-compatible client (tests)
        retriever_opts: dict | None = None,
    ):
        if db is None:
            from falkordb import FalkorDB
            db = FalkorDB(host=host, port=port, password=password or None)
        self._db = db
        self._fixed = fixed_graph_name
        self._retriever_opts = retriever_opts or {}
        self._indexed: set[str] = set()     # graphs we already ran ensure_indexes() on

    # ---- naming ---------------------------------------------------------------
    def graph_name(self, repo: str) -> str:
        """GRAPH_NAME (if configured) wins: handy when you built one graph by hand
        with `python build_graph.py <repo> code_graph`. Otherwise one graph per repo."""
        if self._fixed:
            return self._fixed
        return re.sub(r"[^A-Za-z0-9_.-]", "_", repo.replace("/", "__"))

    def _graph(self, repo: str):
        return self._db.select_graph(self.graph_name(repo))

    # ---- health / state ---------------------------------------------------------
    def ping(self) -> None:
        self._db.connection.ping()

    def close(self) -> None:
        try:
            self._db.connection.close()
        except Exception:
            pass

    def exists(self, repo: str) -> bool:
        """True if the repo's graph has at least one File node."""
        try:
            res = self._graph(repo).ro_query("MATCH (f:File) RETURN count(f) AS n")
            return bool(res.result_set and res.result_set[0][0] > 0)
        except Exception:
            return False        # querying a missing graph raises "empty key"

    def indexed_sha(self, repo: str) -> str | None:
        """Commit the graph reflects (stored on a Meta node), None if unknown.
        A graph built by hand with build_graph.py has no Meta node -> None."""
        try:
            res = self._graph(repo).ro_query("MATCH (m:Meta) RETURN m.sha LIMIT 1")
            return res.result_set[0][0] if res.result_set else None
        except Exception:
            return None

    # ---- write path -------------------------------------------------------------
    def replace(self, repo: str, sha: str, files, functions, imports, calls) -> None:
        name = self.graph_name(repo)
        tmp_name = name + _BUILDING_SUFFIX

        try:                                   # clear leftovers of a crashed build
            self._db.select_graph(tmp_name).delete()
        except Exception:
            pass

        tmp = self._db.select_graph(tmp_name)
        try:
            load_graph(tmp, files, functions, imports, calls)
            tmp.query("CREATE (:Meta {sha: $sha, indexed_at: timestamp()})", {"sha": sha})
            self._db.connection.rename(tmp_name, name)   # atomic; overwrites the live graph
        except Exception:
            try:
                tmp.delete()                   # never leave a half-built graph behind
            except Exception:
                pass
            raise
        logger.info("graph '%s' now at %s (%d files, %d functions, %d calls)",
                    name, sha[:7], len(files), len(functions), len(calls))

    # ---- read path --------------------------------------------------------------
    def context(self, repo: str, diff: str) -> GraphContext:
        name = self.graph_name(repo)
        retriever = GraphContextRetriever(self._db.select_graph(name), **self._retriever_opts)
        if name not in self._indexed:       # covers graphs built by an older build_graph.py
            retriever.ensure_indexes()
            self._indexed.add(name)
        return retriever.retrieve(diff)