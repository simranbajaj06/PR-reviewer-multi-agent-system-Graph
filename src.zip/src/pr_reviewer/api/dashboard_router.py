"""Read-only REST endpoints for the review dashboard.

All endpoints return JSON and are CORS-friendly so a separate frontend
(or a static HTML page served from the same FastAPI app) can consume them.
"""
from typing import Any

from fastapi import APIRouter, Query

from src.pr_reviewer.adapters.persistence.db import get_review, get_stats, list_reviews

router = APIRouter(prefix="/api")


@router.get("/reviews")
def get_reviews(
    repo: str | None = Query(default=None, description="Filter by repo full name"),
    limit: int = Query(default=50, ge=1, le=200),
) -> dict[str, Any]:
    """List recent reviews with optional repo filter."""
    rows = list_reviews(repo=repo, limit=limit)
    # Lightweight enrichment: add agent badges from stored findings
    # (In a real system you'd denormalize this; for hackathon we do it here.)
    for r in rows:
        review = get_review(r["id"])
        if review and review.get("findings"):
            agents = sorted({f["agent_type"] for f in review["findings"]})
            r["agents"] = agents
        else:
            r["agents"] = []
    return {"reviews": rows}


@router.get("/reviews/{review_id}")
def get_review_detail(review_id: int) -> dict[str, Any]:
    """Full review detail including all findings."""
    review = get_review(review_id)
    if review is None:
        return {"error": "Review not found"}
    return {"review": review}


@router.get("/stats")
def dashboard_stats() -> dict[str, Any]:
    """High-level stats for the dashboard header cards."""
    return {"stats": get_stats()}


@router.get("/repos")
def list_repos() -> dict[str, Any]:
    """All repos that have at least one review."""
    return {"repos": get_stats()["repos"]}
